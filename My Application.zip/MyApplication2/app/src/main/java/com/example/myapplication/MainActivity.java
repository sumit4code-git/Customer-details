package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {
        EditText et_name,et_age;
        Button btn_view,btn_add;
        Switch is_active;
        ListView iv_customerlist;
    DatabaseHelper db=new DatabaseHelper(MainActivity.this);
    ArrayAdapter arrayadapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et_name=findViewById(R.id.et_name);
        et_age=findViewById(R.id.et_age);
        btn_add=findViewById(R.id.btn_aadd);
        btn_view=findViewById(R.id.btn_view);
        is_active=findViewById(R.id.sw_active);
        iv_customerlist=findViewById(R.id.list);
        ShowCustomerOnListview(db);
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Customer_Model customerModel=new Customer_Model(-1,"error",0,false);
                try { 
                    customerModel = new Customer_Model(-1, et_name.getText().toString(), Integer.parseInt(et_age.getText().toString()), is_active.isChecked());
                    Toast.makeText(MainActivity.this, customerModel.toString(), Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    Toast.makeText(MainActivity.this, "error occurred", Toast.LENGTH_SHORT).show();
//                    customerModel=new Customer_Model(-1,"error",0,false);
                }
                DatabaseHelper datahelp= new DatabaseHelper(MainActivity.this);
               boolean sucess= datahelp.addone(customerModel);
//                Toast.makeText(MainActivity.this, "Sucess"+sucess, Toast.LENGTH_SHORT).show();
                ShowCustomerOnListview(db);

            }
        });
        btn_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                DatabaseHelper db=new DatabaseHelper(MainActivity.this);
//                List<Customer_Model> everyone = db.getEveryone();
//                Toast.makeText(MainActivity.this, everyone.toString(), Toast.LENGTH_SHORT).show();
                ShowCustomerOnListview(db);
            }
        });
        iv_customerlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Customer_Model itemAtPosition = (Customer_Model) parent.getItemAtPosition(position);
                db.deleteone(itemAtPosition);
                ShowCustomerOnListview(db);
                Toast.makeText(MainActivity.this, "DELETE ITEM" +itemAtPosition.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void ShowCustomerOnListview(DatabaseHelper db) {
        arrayadapter = new ArrayAdapter<Customer_Model>(MainActivity.this, android.R.layout.simple_list_item_1, db.getEveryone());
        iv_customerlist.setAdapter(arrayadapter);
    }
}